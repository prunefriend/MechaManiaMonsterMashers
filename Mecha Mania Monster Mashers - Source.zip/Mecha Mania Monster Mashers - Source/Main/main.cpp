#include <GameEngine.h>
#include <Windows.h>

int main()
{
	CGameEngine::Run();

	return 0;
}