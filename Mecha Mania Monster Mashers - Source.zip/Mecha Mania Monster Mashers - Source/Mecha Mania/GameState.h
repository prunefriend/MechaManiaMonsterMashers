//
// Bachelor of Software Engineering
// Media Design School
// Auckland
// New Zealand
//
// (c) 2017 Media Design School.
//
// File Name		 : GameState.h
// Description		 : Header for gamestate
// Author			 : Humanity's Last Hope
// Mail (team leader): jack.mair7246@mediadesign.school.nz
//
#pragma once

class CGameEngine;

class IGameState
{
public:
	virtual ~IGameState();

	virtual void Init() = 0;
	virtual void Cleanup() = 0;

	virtual void Draw(CGameEngine* _gameEngine) = 0;
	virtual void Step(CGameEngine* _gameEngine) = 0;
protected:
	IGameState();
};

