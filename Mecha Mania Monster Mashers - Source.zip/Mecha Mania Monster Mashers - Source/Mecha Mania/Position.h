//
// Bachelor of Software Engineering
// Media Design School
// Auckland
// New Zealand
//
// (c) 2017 Media Design School.
//
// File Name		 : Position.h
// Description		 : Header for position class
// Author			 : Humanity's Last Hope
// Mail (team leader): jack.mair7246@mediadesign.school.nz
//
#pragma once

struct TPosition
{
	int m_iX;
	int m_iY;

	bool operator==(const TPosition& other) const
	{
		return m_iX == other.m_iX && m_iY == other.m_iY;
	}
	bool operator!=(const TPosition& other) const
	{
		return !(*this == other);
	}
};