//
// Bachelor of Software Engineering
// Media Design School
// Auckland
// New Zealand
//
// (c) 2017 Media Design School.
//
// File Name		 : Movable.cpp
// Description		 : Checks if an object is movable
// Author			 : Humanity's Last Hope
// Mail (team leader): jack.mair7246@mediadesign.school.nz
//
#include "Movable.h"
#include "Position.h"

CMovable::CMovable(CBoard* _pBoard, const TPosition& _posGridPosition) :
	m_pBoard(_pBoard),
	m_posGridPosition(_posGridPosition)
{}

CMovable::~CMovable() 
{}

bool CMovable::Move(EDIRECTION, CGameEngine*)
{
	return false;
}

TPosition CMovable::GetPosition() const
{
	return m_posGridPosition;
}
