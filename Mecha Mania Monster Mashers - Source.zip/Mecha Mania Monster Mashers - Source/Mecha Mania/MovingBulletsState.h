//
// Bachelor of Software Engineering
// Media Design School
// Auckland
// New Zealand
//
// (c) 2017 Media Design School.
//
// File Name		 : MovingBulletState.h
// Description		 : Header for moving bullet
// Author			 : Humanity's Last Hope
// Mail (team leader): jack.mair7246@mediadesign.school.nz
//
#pragma once
#include "GameState.h"
class CMovingBulletsState : public IGameState
{
public:
	CMovingBulletsState();
	virtual ~CMovingBulletsState();

	// Inherited via IGameState
	virtual void Init() override;
	virtual void Cleanup() override;
	virtual void Draw(CGameEngine * _pGameEngine) override;
	virtual void Step(CGameEngine * _pGameEngine) override;
};

