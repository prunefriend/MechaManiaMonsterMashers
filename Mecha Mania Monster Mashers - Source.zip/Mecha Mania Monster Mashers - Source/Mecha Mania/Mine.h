//
// Bachelor of Software Engineering
// Media Design School
// Auckland
// New Zealand
//
// (c) 2017 Media Design School.
//
// File Name		 : Mine.h
// Description		 : Header for mine class
// Author			 : Humanity's Last Hope
// Mail (team leader): jack.mair7246@mediadesign.school.nz
//
#pragma once
#include "Movable.h"
#include "Enums.h"
#include "Position.h"
class CGameEngine;


class CMine : public CMovable
{
public:
	CMine(CBoard*, TPosition);
	~CMine();

	TPosition getPosition();
	//void setPosition(TPosition _gridPosition);
	void ArmMine();
	bool isArmed();
	bool Move(EDIRECTION _eDirection, CGameEngine* _pGameEngine);
	void bombBlown();

	//CMine* getMine();

private:

	bool m_isArmed = false;
};

