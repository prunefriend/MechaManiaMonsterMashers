//
// Bachelor of Software Engineering
// Media Design School
// Auckland
// New Zealand
//
// (c) 2017 Media Design School.
//
// File Name		 : Util.h
// Description		 : Header for util class
// Author			 : Humanity's Last Hope
// Mail (team leader): jack.mair7246@mediadesign.school.nz
//
#pragma once

#include <Windows.h>
#include "Enums.h"

struct TPosition;

namespace Util
{
	TPosition GetNextPosition(const TPosition& _rkpos, EDIRECTION _eDirection);
	
}

inline void GotoXY(int _iX, int _iY) {
	COORD point;
	point.X = _iX;
	point.Y = _iY;
	SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), point);
}