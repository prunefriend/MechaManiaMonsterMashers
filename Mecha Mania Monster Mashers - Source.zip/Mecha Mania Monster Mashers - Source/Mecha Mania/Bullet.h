//
// Bachelor of Software Engineering
// Media Design School
// Auckland
// New Zealand
//
// (c) 2017 Media Design School.
//
// File Name		 : Bullet.h
// Description		 : Header for bullet class
// Author			 : Humanity's Last Hope
// Mail (team leader): jack.mair7246@mediadesign.school.nz
//
#pragma once

#include <vector>

#include "Movable.h"
#include "Enums.h"
#include "Position.h"

class CGameEngine;

class CBullet : public CMovable
{
public:
	CBullet(CBoard*, CGameEngine&, const TPosition&, EDIRECTION);
	virtual ~CBullet() override;
	bool Move(EDIRECTION _eDirection, CGameEngine* _pGameEngine);

	EDIRECTION GetDirection();
	void SetDirection(EDIRECTION);
	bool IsDestroyed() const;
	void SetDestroyed();
	int GetDamage() const;

private:
	bool m_bIsDestroyed;
	const int m_iDamage;
	EDIRECTION m_eMovingDir;
	CGameEngine& m_rGameEngine;
};

