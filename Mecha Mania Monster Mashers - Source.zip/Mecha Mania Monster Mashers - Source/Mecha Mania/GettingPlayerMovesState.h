//
// Bachelor of Software Engineering
// Media Design School
// Auckland
// New Zealand
//
// (c) 2017 Media Design School.
//
// File Name		 : GettingPlayerMovesState.h
// Description		 : Header for getting player move state
// Author			 : Humanity's Last Hope
// Mail (team leader): jack.mair7246@mediadesign.school.nz
//
#include "GameEngine.h"
#include "Player.h"
#include "GameState.h"

#pragma once

class CGettingPlayerMovesState : public IGameState
{
public:
	CGettingPlayerMovesState();
	virtual ~CGettingPlayerMovesState() override;

	void ProcessUserInput(CGameEngine* _pGameEngine);
	

	// Inherited via IGameState
	virtual void Init() override;

	virtual void Cleanup() override;

	virtual void Draw(CGameEngine * _pGameEngine) override;

	virtual void Step(CGameEngine * _pGameEngine) override;

	void ResetLocalCount()
	{
		iLocalCount = 0;
	}

	int GetLocalCount()
	{
		return iLocalCount;
	}

private:

	int iRealPlayerCount = 0;
	int iMoveCount = 0;
	int iLocalCount = 0;
};

