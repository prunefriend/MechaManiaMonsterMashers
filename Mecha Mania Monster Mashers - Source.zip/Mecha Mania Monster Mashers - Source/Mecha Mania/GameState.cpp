//
// Bachelor of Software Engineering
// Media Design School
// Auckland
// New Zealand
//
// (c) 2017 Media Design School.
//
// File Name		 : GameState.cpp
// Description		 : pure virtual
// Author			 : Humanity's Last Hope
// Mail (team leader): jack.mair7246@mediadesign.school.nz
//
#include "GameState.h"



IGameState::IGameState()
{
}


IGameState::~IGameState()
{
}
