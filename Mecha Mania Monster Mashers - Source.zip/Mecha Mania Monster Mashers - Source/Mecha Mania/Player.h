//
// Bachelor of Software Engineering
// Media Design School
// Auckland
// New Zealand
//
// (c) 2017 Media Design School.
//
// File Name		 : Player.h
// Description		 : Header for player class
// Author			 : Humanity's Last Hope
// Mail (team leader): jack.mair7246@mediadesign.school.nz
//
#include "Enums.h"
#include "Mecha.h"
#include <vector>
#include <queue>

#pragma once

class CPlayer
{
public:
	CPlayer(TPosition _posMechaGridPosition, EDIRECTION _eMechaFacingDir, CBoard* _pBoard, int _ID);
	~CPlayer();
	void SetStartingPos(TPosition _posMechaGridPosition, EDIRECTION _eMechaFacingDir);
	CMecha* GetMecha();
	std::queue<ECOMMANDS>& GetMoveList();
	std::vector<char>& GetOutMove();
	bool bDead = false;
	bool CheckDeath();
	void ResetOutMoves();


private:
	int m_iD;
	bool m_bisAlive;
	CMecha m_Mecha;
	std::vector<char> m_veccOutMove;
	std::queue<ECOMMANDS> m_MoveList;
};

