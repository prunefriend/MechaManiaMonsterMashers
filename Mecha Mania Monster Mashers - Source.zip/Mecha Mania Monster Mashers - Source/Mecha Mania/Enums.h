//
// Bachelor of Software Engineering
// Media Design School
// Auckland
// New Zealand
//
// (c) 2017 Media Design School.
//
// File Name		 : Enums.h
// Description		 : Header for enums
// Author			 : Humanity's Last Hope
// Mail (team leader): jack.mair7246@mediadesign.school.nz
//
#pragma once

enum ECOMMANDS
{
	MOVEONE = 11,
	MOVETWO = 12,
	MOVETHREE = 13,
	MOVEBACK = 14,
	ROTATECLOCKWISE = 21,
	ROTATEANTICLOCKWISE = 22,
	FLIP = 23,
	SHOOT = 31,
	PUSH = 32,
	PLACEMINE = 33
};
enum EENVIRONMENT
{
	FLOOR,
	WATER,
	PIT
};
enum EDIRECTION
{
	WEST,
	NORTH,
	EAST,
	SOUTH,
	NODIR
};
enum EROTATION
{
	CLOCKWISE,
	ANTICLOCKWISE,
	ONEEIGHTY
};