//
// Bachelor of Software Engineering
// Media Design School
// Auckland
// New Zealand
//
// (c) 2017 Media Design School.
//
// File Name		 : Util.cpp
// Description		 : Extra tools for handling mecha
// Author			 : Humanity's Last Hope
// Mail (team leader): jack.mair7246@mediadesign.school.nz
//
#include "Util.h"
#include "Position.h"

TPosition Util::GetNextPosition(const TPosition & _rkpos, EDIRECTION _eDirection)
{
	TPosition newPos;
	switch (_eDirection)
	{
	case WEST:
		newPos = { _rkpos.m_iX - 1, _rkpos.m_iY };
		break;
	case NORTH:
		newPos = { _rkpos.m_iX, _rkpos.m_iY - 1 };
		break;
	case EAST:
		newPos = { _rkpos.m_iX + 1, _rkpos.m_iY };
		break;
	case SOUTH:
		newPos = { _rkpos.m_iX, _rkpos.m_iY + 1 };
		break;
	case NODIR:
	default:
		newPos = _rkpos;
		break;
	}

	return newPos;
}
