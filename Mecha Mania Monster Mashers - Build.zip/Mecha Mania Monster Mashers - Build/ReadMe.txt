---Mecha Mania Monster Mashers---
created by Humanity's Last Hope

Team members:
Lance Chaney
Madeleine Day
Jack Mair
Sebastian Tengdahl

Media Design School 2017